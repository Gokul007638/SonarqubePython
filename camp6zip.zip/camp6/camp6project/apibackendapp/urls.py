from django.urls import path

from . import views
from .views import post_list, review_list, post_details_view,post_search_by_title_view

urlpatterns=[
    path('posts',post_list),
    path('reviews',review_list),
    path('posts/<int:passed_id>',post_details_view),
    path('posts/<str:post_title>', post_search_by_title_view, name='post_search_by_title'),
    path('api/user/signup',views.SignupAPIView.as_view(),name="user-signup"),
    path('api/user/login', views.LoginAPIView.as_view(), name="user-login")
]
