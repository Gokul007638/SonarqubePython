from django.contrib.auth import authenticate
from django.http import JsonResponse, HttpResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from rest_framework import status
from rest_framework.authtoken.models import Token
from rest_framework.decorators import permission_classes, api_view
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.status import HTTP_401_UNAUTHORIZED
from rest_framework.views import APIView

from .models import Post,Reviews
from .serializers import PostSerializer, ReviewsSerializer, SignupSerializer, LoginSerializer
from rest_framework.parsers import JSONParser

#implement logic  for signup class based view
class SignupAPIView(APIView):


    def post(self, request):
        serializer = SignupSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            res={'status':status.HTTP_201_CREATED}
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class LoginAPIView(APIView):
    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        if serializer.is_valid():
            username= serializer.validated_data["username"]
            password= serializer.validated_data["password"]
            user = authenticate(request, username=username, password=password)

            if user is not None:
                token = Token.objects.get(user=user)
                response = {
                    "status": status.HTTP_200_OK,
                    "message": "success",
                    "data": {
                         "Token": token.key
                    }
                }
                return Response(response, status=status.HTTP_200_OK)
            else:
                response = {
                    "status": status.HTTP_401_UNAUTHORIZED,
                    "message": "Wrong Credentials",
                }
                return Response(response, status=status.HTTP_401_UNAUTHORIZED)

        response = {
            "status": status.HTTP_400_BAD_REQUEST,
            "message": "bad request",

        }
        return Response(response, status=status.HTTP_400_BAD_REQUEST)





# Create your views here.
@permission_classes((IsAuthenticated,))
@csrf_exempt
@api_view(['GET','POST'])
@permission_classes((IsAuthenticated,))
def post_list(request):
    if request.method == "GET":
        posts_list = Post.objects.all()
        posts_list_serializer = PostSerializer(posts_list,many= True)
        return JsonResponse(posts_list_serializer.data, safe=False)

    elif request.method == "POST":
        # get the data from the default paramter:
        # request_data = JSONParser().parse(request)
        # request_data = request.data
        post_title = request.POST.get('post_title')
        post_description = request.POST.get('post_description')
        post_shortname = request.POST.get('post_shortname')
        post_author = request.POST.get('post_author')
        category = request.POST.get('category')
        post_image = request.FILES.get('post_image')
        request_data = {
            'post_title': post_title,
            'post_description': post_description,
            'post_shortname': post_shortname,
            'post_author': post_author,
            'Category': category,
            'post_image': post_image
        }
        # using a serializer serialize the parsed json
        post_add_serializer = PostSerializer(data=request_data)
        # checking if serializer returns a valid data
        if post_add_serializer.is_valid():
            post_add_serializer.save()

            # send back the respond code and the copy of data added as JSON
            return JsonResponse(post_add_serializer.data, status=201)
        return JsonResponse(post_add_serializer.errors, status=400)


@csrf_exempt
@permission_classes((IsAuthenticated,))
@api_view(['GET','PUT','DELETE'])
@permission_classes((IsAuthenticated,))
def post_details_view(request,passed_id):
    #to get the single object based on the id
    post_details=Post.objects.get(id=passed_id)

    if request.method=="GET" or request.method=="HEAD":
        post_details_serializer = PostSerializer(post_details)
        return JsonResponse(post_details_serializer.data,safe=False,status=200)
    elif request.method == "PUT":
        #for saving the data we need to parse to json format
        request_data = JSONParser().parse(request)
        post_update_serializer=(PostSerializer(post_details,data=request_data))
        if post_update_serializer.is_valid():
            post_update_serializer.save()
            return JsonResponse(post_update_serializer.data,safe=False,status=201)
        return JsonResponse(post_update_serializer.errors,status=400)
    elif request.method=="DELETE":
        post_details.delete()
        return HttpResponse(status=204)

@csrf_exempt
def post_search_by_title_view(request, post_title):
    if request.method == "GET":
        try:
            post_details = Post.objects.get(post_title=post_title)
            post_details_serializer = PostSerializer(post_details)
            return JsonResponse(post_details_serializer.data, safe=False, status=200)
        except Post.DoesNotExist:
            return JsonResponse({'error': 'Post not found'}, status=404)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)




@csrf_exempt
def review_list(request):
    if request.method=="GET":
        reviews_list=Reviews.objects.all()
        reviews_list_serializer= ReviewsSerializer(reviews_list,many=True)
        return JsonResponse( reviews_list_serializer.data,safe=False)


    elif request.method == "POST":

        request_data = JSONParser().parse(request)

        review_add_serializer = ReviewsSerializer(data=request_data)

        if review_add_serializer.is_valid():
            review_add_serializer.save()

            return JsonResponse(review_add_serializer.data, status=201)

        return JsonResponse(review_add_serializer.errors, status=400)




