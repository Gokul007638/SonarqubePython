from django.contrib import admin
from rest_framework.authtoken.models import Token

from .models import Post,Category,Reviews
# Register your models here.
admin.site.register(Token)
admin.site.register(Post)
admin.site.register(Category)
admin.site.register(Reviews)