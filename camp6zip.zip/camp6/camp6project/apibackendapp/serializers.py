from django.contrib.auth.hashers import make_password
from django.contrib.auth.models import User
from rest_framework import serializers


from .models import Category,Reviews,Post

class UserSerializer(serializers.ModelSerializer):  #another method, manuallly creating
    class Meta:
        model = User
        fields = ['id', 'username','email']


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model=Category
        fields= '__all__'


# class ServiceCategorySerializer:
#     pass


class PostSerializer(serializers.ModelSerializer):

    
    
    post_title=serializers.CharField(max_length=100, min_length=10, allow_blank=False, trim_whitespace=True) #for validation,inbuilt in django
    Category = serializers.PrimaryKeyRelatedField(queryset=Category.objects.all())  #this queryset will check the data on category table.. if not it will display an error
    Category_details = CategorySerializer(source='Category',read_only=True)
    post_author = serializers.PrimaryKeyRelatedField(queryset=User.objects.all())
    post_author_details = UserSerializer(source='post_author',read_only=True)

    # post_author_username = serializers.SerializerMethodField()

    class Meta:
        model = Post
        fields = ['post_author', 'post_author_details', 'post_description', 'post_shortname','post_title','Category','Category_details','post_image']

    # def get_post_author_username(self,obj):
    #     return obj.post_author.username

    def create(self, validated_data):
        validated_data['post_title']=validated_data['post_title'].upper() #for converting post_title to uppercase
        return super().create(validated_data)







class ReviewsSerializer(serializers.ModelSerializer):
    """Reviews_author = UserSerializer"""
    review_author = (serializers.PrimaryKeyRelatedField(queryset=User.objects.all()))
    reviews_author_details = UserSerializer(source='review_author', read_only=True)
    class Meta:
        model= Reviews
        fields= ['post','rating','description','review_author','reviews_author_details']


class SignupSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['username','password']

    def create(self, validated_data): #this is to show password as a secret code in databse
        validated_data["password"]=(make_password(validated_data["password"]))

        return super(SignupSerializer,self).create(validated_data)

#serializer for login
class LoginSerializer(serializers.ModelSerializer):
    username=serializers.CharField()
    class Meta:
        model = User
        fields = ['username','password']